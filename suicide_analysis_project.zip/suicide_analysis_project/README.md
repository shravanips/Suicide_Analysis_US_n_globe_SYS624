suicide_analysis_project/
│
├── data/
│   ├── full_data.csv                                  # Professor's core dataset (2012–2014)
│   │ 
│   ├── stopwords_en.txt                             # Custom stopword list for filtering - not used but kept from begining (practice)
│   │ 
│   ├── death_rates_google/
│   │   └── Death_rates_for_suicide__by_sex__race__Hispanic_origin__and_age__United_States.csv
│   │                                                  # CDC dataset: suicide rates by demographics
│   │ 
│   ├── state_level_suicide_in_years/
│   │   ├── suicide_state_2005.csv
│   │   ├── suicide_state_2014.csv
│   │   ├── suicide_state_2015.csv
│   │   ├── suicide_state_2016.csv
│   │   ├── suicide_state_2017.csv
│   │   ├── suicide_state_2018.csv
│   │   ├── suicide_state_2019.csv
│   │   ├── suicide_state_2020.csv
│   │   └── suicide_state_2022.csv                     # Year-wise state suicide stats
│   │ 
│   └── world_suicide/
│       └── master.csv                                 # Global suicide dataset (1985–2016)
│
│
├── scripts/
│   └── full_data_check.py
│   └── outputs/
│   │   ├── suicide_dashboard_labeled_final.html
│   └── q1_analysis_us.py
│   └── q2_gender_analysis.py
│   └── q3_combined_analysis.py
│   └── q4_state_analysis.py
│   └── q5_analyze_suicide_by_month.py
│   └── q6_analyze_suicide_by_place.py
│   └── q7_analyze_place_vs_demographics.py
│   └── q8_analyze_suicide_by_education.py
│   └── q9_analyze_suicide_by_race.py
│   └── full_us_deathrate_analysis.py
│   └── full_world_suicide_analysis.py
│
├── outputs/
│   └── suicide_by_age_gender_plotly.html
│   └── suicide_by_gender_plotly.html
│   └── q3/
│       ├── bar_race_gender.png  
│       ├── facet_education_race_gender.png 
│       ├── factor_combinations_summary.csv 
│       ├── heatmap_race_education.png 
│       ├── sunburst_sex_race_education.html 
│       ├── sunburst_year_gender_age.html
│       ├── sankey_race_edu_gender.html
│   └── q4_combined_outputs/
│       ├── animated_choropleth_with_table.html
│       ├── barplot_suicides_by_year.png
│       ├── chord_top5_states.html
│       ├── cleaned_state_suicide_data.csv
│   └── q5_outputs/
│       ├── animated_suicide_trend.html
│       ├── barplot_suicides_per_month.png
│       ├── boxplot_age_distribution_by_month.png
│       ├── q5_dashboard.html
│       ├── q5_suicide_by_month.csv
│       ├── radial_calendar_suicide.png
│       ├── streamgraph_monthly_trends.png
│       ├── sunburst_seasonal_suicide.html
│   └── q6_outputs/
│       ├── barplot_suicides_by_place.png
│       ├── lineplot_place_trends_by_year.png
│       ├── q6_dashboard.html
│       ├── q6_suicide_by_place.csv
│       ├── stacked_area_suicide_by_place.png
│       ├── sunburst_place_year.html
│       ├── violinplot_age_by_place.png
│   └── q7_outputs/
│       ├── barplot_place_by_sex.png
│       ├── bump_chart_location_gender_rank.html 
│       ├── chord_gender_place.html
│       ├── q7_dashboard.html
│       ├── q7_place_demographics.csv
│       ├── radial_chart_place_gender_colored.html
│       ├── sankey_sex_place_age.html
│   └── q8_outputs/
│       ├── barplot_education_by_year.png
│       ├── bubble_education_gender.html
│       ├── heatmap_education_by_year.png
│       ├── lineplot_education_gender.png
│       ├── q8_dashboard.html
│       ├── q8_suicide_by_education.csv
│       ├── treemap_education_gender.html
│   └── q9_outputs/
│       ├── q9_suicide_by_race.csv
│       ├── barplot_suicides_by_race.png
│       ├── q9_dashboard.html
│       ├── sankey_race_to_gender.html
│   └── q_world_master_analysis/
│       ├── creative_suicide_dashboard.html
│   └── q_us_deathrate_dashboard
│       ├── creative_us_deathrate_dashboard.html
│
├── README.md                                           # Project documentation and layout guide
