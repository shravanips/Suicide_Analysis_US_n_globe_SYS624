# q3_combined_analysis.py - Enhanced a bit for visuals (shravani's notes)
# Author: Shravani Sawant
# Updated: April 17, 2025; 11:18 PM
# Analyzes the dataset = full_data.csv
# Purpose: Analyze combinations of demographic factors and generate impactful visualizations

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from tabulate import tabulate
import os

# Paths Setup
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "../data")
OUTPUT_DIR = os.path.join(BASE_DIR, "../outputs/q3")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Load full_data.csv
full_data_path = os.path.join(DATA_DIR, "full_data.csv")
print("\nLoading full_data.csv...")
df = pd.read_csv(full_data_path)
df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")
df = df[df["intent"].str.lower() == "suicide"]
print(f"Loaded {len(df)} suicide-related records.")

# Create suicide count column
df["suicide_count"] = 1

#  Summary Grouping
grouped = df.groupby(["year", "sex", "race", "education"]).size().reset_index(name="count")
grouped.to_csv(os.path.join(OUTPUT_DIR, "factor_combinations_summary.csv"), index=False)

# Plot 1: Bar Chart (Race × Gender) with Custom Colors and Labels
high_count = grouped[grouped["count"] > 500]
plt.figure(figsize=(12, 6))
sns.barplot(data=high_count, x="race", y="count", hue="sex", palette=["#D0E4EE", "#F5A7A6"])
plt.title("Suicide Counts by Race and Gender (2012–2014)")
plt.ylabel("Number of Suicides")
plt.xticks(rotation=30)
for i in range(len(high_count)):
    plt.text(i, high_count.iloc[i]['count'] + 100, high_count.iloc[i]['count'], ha='center')
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "bar_race_gender.png"))
plt.close()

#  Plot 2: Faceted Bar Chart (Education × Race by Gender)
g = sns.catplot(data=grouped, kind="bar", x="education", y="count", hue="race", col="sex",
                palette="pastel", height=5, aspect=1.2)
g.fig.subplots_adjust(top=0.85)
g.fig.suptitle("Suicide Count by Education, Race, and Gender")
g.savefig(os.path.join(OUTPUT_DIR, "facet_education_race_gender.png"))
plt.close()

# Plot 3: Heatmap (Race × Education) with Soft Color
pivot = grouped.pivot_table(values="count", index="race", columns="education", aggfunc="sum", fill_value=0)
plt.figure(figsize=(10, 6))
sns.heatmap(pivot, annot=True, fmt=".0f", cmap="YlGnBu")
plt.title("Heatmap: Suicide Count by Race and Education")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "heatmap_race_education.png"))
plt.close()

# Plot 4: Sunburst Chart (Sex → Race → Education)
fig1 = px.sunburst(
    grouped,
    path=["sex", "race", "education"],
    values="count",
    color="count",
    color_continuous_scale="sunset",
    title="Sunburst: Sex → Race → Education (Suicide Counts)"
)
fig1.write_html(os.path.join(OUTPUT_DIR, "sunburst_sex_race_education.html"))

# Plot 5: Sunburst (Year → Gender → Age)
sunburst_df = df.groupby(['year', 'sex', 'age']).size().reset_index(name='count')
fig2 = px.sunburst(
    sunburst_df,
    path=['year', 'sex', 'age'],
    values='count',
    color='count',
    color_continuous_scale='bluered',
    title='Sunburst: Year → Gender → Age'
)
fig2.write_html(os.path.join(OUTPUT_DIR, "sunburst_year_gender_age.html"))

# Plot 6: Layered Sankey Diagram (Race → Education → Gender)
sankey_data = df.groupby(["race", "education", "sex"]).size().reset_index(name="count")
labels = list(pd.unique(sankey_data[['race', 'education', 'sex']].values.ravel('K')))
label_map = {label: idx for idx, label in enumerate(labels)}

sources = sankey_data['race'].map(label_map).tolist()
targets = sankey_data['education'].map(label_map).tolist()
values = sankey_data['count'].tolist()

edu_sex_data = df.groupby(["education", "sex"]).size().reset_index(name="count")
sources += edu_sex_data['education'].map(label_map).tolist()
targets += edu_sex_data['sex'].map(label_map).tolist()
values += edu_sex_data['count'].tolist()

# Color links based on source category (race + separate colors for M and F)
colors = []
race_color_map = {
    "White": "rgba(241,196,15,0.7)",
    "Black": "rgba(231,76,60,0.7)",
    "Hispanic": "rgba(39,174,96,0.7)",
    "Asian/Pacific Islander": "rgba(52,152,219,0.7)",
    "Native American/Native Alaskan": "rgba(155,89,182,0.7)",
    "F": "rgba(255, 182, 193, 1)",    # pink rgba(255, 182, 193, 1) rgba(255,99,132,0.8)
    "M": "rgba(100,100,255,0.6)"     # soft blue for male
}

for race in sankey_data['race']:
    colors.append(race_color_map.get(race, "rgba(127,140,141,0.7)"))
for sex in edu_sex_data['sex']:
    colors.append(race_color_map.get(sex, "rgba(127,140,141,0.7)"))

fig3 = go.Figure(data=[go.Sankey(
    arrangement="snap",
    node=dict(
        pad=15,
        thickness=18,
        line=dict(color="black", width=0.5),
        label=labels,
        color="lightgray"
    ),
    link=dict(
        source=sources,
        target=targets,
        value=values,
        color=colors
    )
)])

fig3.update_layout(
    title_text="Layered Sankey Diagram: Race → Education → Gender",
    font_size=12,
    height=600,
    margin=dict(l=20, r=20, t=40, b=20)
)
fig3.write_html(os.path.join(OUTPUT_DIR, "sankey_race_edu_gender.html"))

# Console Summary of Top 5 Combinations
top_5 = grouped.sort_values("count", ascending=False).head(5)
print("\nTop 5 Suicide Factor Combinations (Race/Gender/Education):")
print(tabulate(top_5, headers="keys", tablefmt="grid"))

print("\nAll visualizations and summary files saved in:", OUTPUT_DIR)
