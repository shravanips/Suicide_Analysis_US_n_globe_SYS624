# full_us_deathrate_analysis.py
# Question 11: What age, sex, and racial trends can be observed from U.S. suicide death rates?
# Author: Shravani Sawant
# Date Last Edited: April 25, 2025 ; 10:40 pm
#
# Purpose:
#     This script analyzes U.S. suicide death rate trends using the CDC dataset,
#     focusing on age groups, sex, race, and generational changes. It includes:
#     - Age-group suicide trends over years (streamgraph)
#     - Suicide rate differences between males and females
#     - Change in suicide rates across decades
#     - Demographic profiling (sex × race × age) via sunburst charts
#     - Gender suicide gap evolution (dumbbell plots)
#     - Animated bubble views for age group vulnerabilities
#     - Concentration analysis via Lorenz curves
#     - Radar charts highlighting post-2010 vulnerable groups
#     All visual outputs are compiled into an interactive HTML dashboard.
#
# Dataset Used:
#   Death_rates_for_suicide__by_sex__race__Hispanic_origin__and_age__United_States.csv
# Path: data/death_rates_google/Death_rates_for_suicide__by_sex__race__Hispanic_origin__and_age__United_States.csv


import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import plotly.io as pio
import os
from tabulate import tabulate


# Setup Output Directory
output_dir = '../outputs/q_us_deathrate_dashboard/'
os.makedirs(output_dir, exist_ok=True)
dashboard_html_path = output_dir + 'creative_us_deathrate_dashboard.html'


# Load and Clean Data
file_path = '../data/death_rates_google/Death_rates_for_suicide__by_sex__race__Hispanic_origin__and_age__United_States.csv'
df = pd.read_csv(file_path)

df.columns = df.columns.str.strip()
df.rename(columns={
    'YEAR': 'Year',
    'AGE': 'Age Group',
    'STUB_LABEL': 'Sex',
    'STUB_NAME': 'Race',
    'ESTIMATE': 'Death Rate'
}, inplace=True)
df['Death Rate'] = pd.to_numeric(df['Death Rate'], errors='coerce')
df = df.dropna(subset=['Death Rate'])
df['Sex'] = df['Sex'].str.extract(r'(Male|Female)', expand=False)

print("\n***** Data Loaded and Cleaned Successfully *****")

figures = []


# Q1: Streamgraph
print("\n ---------------- ")
print("\n Q1: Suicide Rates Flow by Age Groups Over Years ")
q1_df = df[df['Age Group'] != 'All ages']
q1_df = q1_df.groupby(['Year', 'Age Group'])['Death Rate'].mean().reset_index()
print(tabulate(q1_df.head(10), headers='keys', tablefmt='pretty'))
fig1 = px.area(q1_df, x='Year', y='Death Rate', color='Age Group',
               title='Q1: Suicide Rates by Age Group Over Years (Streamgraph)',
               color_discrete_sequence=px.colors.sequential.Sunset)
figures.append(fig1)


# Q2: Grouped Horizontal Bar
print("\n ---------------- ")
print("\n Q2: Suicide Rates by Sex Across Age Groups (Cleaned) ")
q2_df = df[df['Age Group'] != 'All ages']
q2_df = q2_df.groupby(['Age Group', 'Sex'])['Death Rate'].mean().reset_index()
q2_df['Age Group'] = pd.Categorical(q2_df['Age Group'], ordered=True, categories=[
    '10-14 years', '15-19 years', '20-24 years', '25-34 years', '35-44 years',
    '45-54 years', '55-64 years', '65-74 years', '75-84 years', '85 years and over'])
q2_df.sort_values('Age Group', inplace=True)
print(tabulate(q2_df.head(10), headers='keys', tablefmt='pretty'))
fig2 = px.bar(q2_df, x='Death Rate', y='Age Group', color='Sex', barmode='group',
              title='Q2: Suicide Rates by Sex Across Age Groups (Cleaned)',
              orientation='h', color_discrete_sequence=px.colors.qualitative.Pastel)
figures.append(fig2)


# Q3: Diverging Bar Chart
print("\n ---------------- ")
print("\n Q3: Steepest Rise in Suicide Rate by Age Group ")
first_year = df['Year'].min()
last_year = df['Year'].max()
q3_df_start = df[df['Year'] == first_year].groupby('Age Group')['Death Rate'].mean()
q3_df_end = df[df['Year'] == last_year].groupby('Age Group')['Death Rate'].mean()
q3_df = pd.DataFrame({'Start': q3_df_start, 'End': q3_df_end}).dropna().reset_index()
q3_df['Change'] = q3_df['End'] - q3_df['Start']
print(tabulate(q3_df.sort_values('Change', ascending=False), headers='keys', tablefmt='pretty'))
fig3 = px.bar(q3_df.sort_values('Change'), x='Change', y='Age Group', orientation='h',
              color='Change', title='Q3: Change in Suicide Rates by Age Group (Diverging Bar)',
              color_continuous_scale='RdBu')
figures.append(fig3)


# Q4: Sunburst Chart
print("\n ---------------- ")
print("\n Q4: Suicide Risk Profile: Sex × Race × Age ")
q4_df = df.groupby(['Sex', 'Race', 'Age Group'])['Death Rate'].mean().reset_index()
print(tabulate(q4_df.head(10), headers='keys', tablefmt='pretty'))
fig4 = px.sunburst(q4_df, path=['Sex', 'Race', 'Age Group'], values='Death Rate',
                   title='Q4: Suicide Risk Profile (Sunburst)',
                   color='Death Rate', color_continuous_scale='Tealgrn')
figures.append(fig4)


# Q5: Dumbbell Plot
print("\n ---------------- ")
print("\n Q5: Gender Suicide Gap Evolution ")
q5_df = df.groupby(['Year', 'Sex'])['Death Rate'].mean().reset_index()
fig5 = go.Figure()
for year in sorted(q5_df['Year'].unique()):
    male = q5_df[(q5_df['Year'] == year) & (q5_df['Sex'] == 'Male')]['Death Rate'].values
    female = q5_df[(q5_df['Year'] == year) & (q5_df['Sex'] == 'Female')]['Death Rate'].values
    if len(male) > 0 and len(female) > 0:
        fig5.add_trace(go.Scatter(x=[female[0], male[0]], y=[year, year],
                                  mode='lines+markers', marker=dict(size=7),
                                  name=str(year)))
fig5.update_layout(title='Q5: Gender Gap in Suicide Rates Over Years (Dumbbell Plot)',
                   xaxis_title='Death Rate', yaxis_title='Year')
figures.append(fig5)


# Q6: Animated Bubble Chart
print("\n ---------------- ")
print("\n Q6: Age Group Suicide Vulnerabilities Over Time ")
q6_df = df[df['Age Group'] != 'All ages']
q6_df = q6_df.groupby(['Year', 'Age Group'])['Death Rate'].mean().reset_index()
fig6 = px.scatter(q6_df, x='Age Group', y='Death Rate', animation_frame='Year', size='Death Rate',
                  color='Age Group', size_max=45,
                  title='Q6: Animated Bubble View of Age Group Vulnerability')
figures.append(fig6)


# Q7: Lorenz Curve
print("\n ---------------- ")
print("\n Q7: Lorenz Curve: Suicide Rate Concentration by Age ")
q7_df = df[df['Age Group'] != 'All ages']
q7_df = q7_df.groupby('Age Group')['Death Rate'].mean().sort_values().reset_index()
cumsum = np.cumsum(q7_df['Death Rate']) / q7_df['Death Rate'].sum()
cumsum = np.insert(cumsum, 0, 0)
fig7 = go.Figure()
fig7.add_trace(go.Scatter(x=np.linspace(0,1,len(cumsum)), y=cumsum, fill='tozeroy', mode='lines', name='Lorenz Curve'))
fig7.add_trace(go.Scatter(x=[0,1], y=[0,1], mode='lines', name='Perfect Equality', line=dict(dash='dash')))
fig7.update_layout(title='Q7: Lorenz Curve for Suicide Death Rate by Age Group',
                   xaxis_title='Cumulative Share of Age Groups',
                   yaxis_title='Cumulative Share of Death Rates')
figures.append(fig7)


# Q8: Radar Chart
print("\n ---------------- ")
print("\n Q8: Hidden At-Risk Groups Post-2010 ")
q8_df = df[(df['Year'] >= 2010) & (df['Age Group'] != 'All ages')]
q8_df = q8_df.groupby('Age Group')['Death Rate'].mean().reset_index()
fig8 = go.Figure()
fig8.add_trace(go.Scatterpolar(r=q8_df['Death Rate'], theta=q8_df['Age Group'], fill='toself'))
fig8.update_layout(title='Q8: Radar Chart of Suicide Rates Post-2010 (Age Groups)',
                   polar=dict(radialaxis=dict(visible=True)), showlegend=False)
figures.append(fig8)


# Save HTML Dashboard
with open(dashboard_html_path, 'w') as f:
    f.write("<html><head><title>US Suicide Death Rate Dashboard</title></head><body style='font-family:sans-serif;'>")
    f.write("<h1 style='text-align:center;'>Creative US Suicide Death Rate Dashboard (Updated)</h1>")
    for i, fig in enumerate(figures, 1):
        f.write(f"<h2>Chart {i}</h2>")
        f.write(pio.to_html(fig, full_html=False, include_plotlyjs='cdn'))
        f.write("<hr style='border:1px solid lightgray;'>")
    f.write("</body></html>")

print(f"\n >>> Final Interactive Dashboard saved to: {dashboard_html_path}")
