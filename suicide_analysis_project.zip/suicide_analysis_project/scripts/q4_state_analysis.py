# q4_state_analysis.py
# Question 4: How do suicide rates vary across different U.S. states or regions?
# Author: Shravani Sawant
# Last edited: April 20, 2025 ; 11:25 AM
# Choropleth Labels + Enhancements
# Dataset used: /data/state_level_suicide_in_years (year wise csv files)

import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
import plotly.express as px
import holoviews as hv
from holoviews import opts
from bokeh.io import output_file, save
from tabulate import tabulate
import plotly.io as pio

hv.extension('bokeh')

# Config
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "../data/state_level_suicide_in_years")
OUTPUT_DIR = os.path.join(BASE_DIR, "../outputs/q4_combined_outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Load & Clean
print("\nLoading state-level suicide data...")
all_data = []

for file in os.listdir(DATA_DIR):
    if file.endswith(".csv"):
        path = os.path.join(DATA_DIR, file)
        df = pd.read_csv(path)
        df.columns = df.columns.str.strip().str.lower()

        if set(["year", "state", "rate", "deaths"]).issubset(df.columns):
            df["deaths"] = df["deaths"].astype(str).str.replace(",", "").astype(float)
            df["rate"] = pd.to_numeric(df["rate"], errors="coerce")
            all_data.append(df)

if not all_data:
    print("No valid CSV files to process.")
    exit()

df = pd.concat(all_data, ignore_index=True)
df["year"] = df["year"].astype(int)
print(f">> Successfully loaded and merged {len(df)} rows.")

# Save Cleaned Data (to tally - for shravani only)
df.to_csv(os.path.join(OUTPUT_DIR, "cleaned_state_suicide_data.csv"), index=False)

# Year-wise Bar Plot
total_by_year = df.groupby("year")["deaths"].sum().reset_index()
plt.figure(figsize=(12, 6))
sns.barplot(data=total_by_year, x="year", y="deaths", palette="magma")
plt.title("Total Suicides per Year (2005–2022)")
plt.xlabel("Year")
plt.ylabel("Number of Suicides")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "barplot_suicides_by_year.png"))
plt.show()
print("\n~ Total Suicides by Year:")
print(tabulate(total_by_year, headers="keys", tablefmt="grid"))

# Animated Choropleth with State Labels
df = df.sort_values("year")
state_coords = pd.read_csv("https://raw.githubusercontent.com/plotly/datasets/master/2011_us_ag_exports.csv")
if 'longitude' not in state_coords.columns or 'latitude' not in state_coords.columns:
    state_coords['longitude'] = state_coords['code'].map({
        'AK': -149.5, 'AL': -86.8, 'AR': -92.3, 'AZ': -111.0, 'CA': -119.4, 'CO': -105.5,
        'CT': -72.7, 'DC': -77.0, 'DE': -75.5, 'FL': -81.5, 'GA': -82.9, 'HI': -155.6,
        'IA': -93.0, 'ID': -114.0, 'IL': -89.4, 'IN': -86.1, 'KS': -98.4, 'KY': -84.2,
        'LA': -91.9, 'MA': -71.4, 'MD': -76.6, 'ME': -69.4, 'MI': -85.6, 'MN': -94.6,
        'MO': -91.8, 'MS': -89.4, 'MT': -110.3, 'NC': -79.0, 'ND': -101.0, 'NE': -99.9,
        'NH': -71.5, 'NJ': -74.4, 'NM': -105.8, 'NV': -116.4, 'NY': -74.2, 'OH': -82.9,
        'OK': -97.0, 'OR': -120.5, 'PA': -77.1, 'RI': -71.4, 'SC': -81.1, 'SD': -99.9,
        'TN': -86.5, 'TX': -99.9, 'UT': -111.0, 'VA': -78.6, 'VT': -72.5, 'WA': -120.7,
        'WI': -88.7, 'WV': -80.4, 'WY': -107.2
    })
    state_coords['latitude'] = state_coords['code'].map({
        'AK': 64.2, 'AL': 32.3, 'AR': 35.2, 'AZ': 34.0, 'CA': 36.7, 'CO': 39.5,
        'CT': 41.6, 'DC': 38.9, 'DE': 38.9, 'FL': 27.9, 'GA': 32.1, 'HI': 19.8,
        'IA': 41.8, 'ID': 44.0, 'IL': 40.6, 'IN': 40.2, 'KS': 39.0, 'KY': 37.8,
        'LA': 30.9, 'MA': 42.4, 'MD': 39.0, 'ME': 45.2, 'MI': 44.3, 'MN': 46.7,
        'MO': 37.9, 'MS': 32.3, 'MT': 46.8, 'NC': 35.7, 'ND': 47.5, 'NE': 41.4,
        'NH': 43.1, 'NJ': 40.0, 'NM': 34.5, 'NV': 38.8, 'NY': 43.2, 'OH': 40.4,
        'OK': 35.0, 'OR': 43.8, 'PA': 41.2, 'RI': 41.5, 'SC': 33.8, 'SD': 43.9,
        'TN': 35.5, 'TX': 31.9, 'UT': 39.3, 'VA': 37.4, 'VT': 44.5, 'WA': 47.7,
        'WI': 43.7, 'WV': 38.5, 'WY': 43.0
    })
label_df = state_coords[['code', 'state', 'longitude', 'latitude']].copy()
label_df.columns = ['abbr', 'state_name', 'lon', 'lat']
animated = px.choropleth(
    df,
    locations="state",
    locationmode="USA-states",
    color="rate",
    scope="usa",
    animation_frame="year",
    title="~ Animated Suicide Rate by State (2005–2022)",
    color_continuous_scale="YlGnBu",
    labels={"rate": "Suicide Rate"},
    hover_name="state"
)
animated.update_geos(showlakes=True, lakecolor="lightblue")
animated.update_traces(marker_line_color='black', marker_line_width=0.3)
for _, row in label_df.iterrows():
    animated.add_trace(go.Scattergeo(
        locationmode='USA-states',
        lon=[row['lon']],
        lat=[row['lat']],
        text=row['abbr'],
        mode='text',
        showlegend=False
    ))
choropleth_html = pio.to_html(animated, include_plotlyjs='cdn', full_html=False)

# Adding Table Below for Average
avg_rate = df.groupby("state")["rate"].mean().reset_index().sort_values("rate", ascending=False)
table_html = avg_rate.to_html(index=False, classes="styled-table", border=0)

full_html_path = os.path.join(OUTPUT_DIR, "animated_choropleth_with_table.html")
with open(full_html_path, "w") as f:
    f.write(f"""
    <html>
    <head>
        <title>Animated Choropleth + State Table</title>
        <style>
            body {{ font-family: Arial, sans-serif; text-align: center; }}
            .styled-table-wrapper {{ display: flex; justify-content: center; }}
            .styled-table {{
                margin: 30px auto;
                border-collapse: collapse;
                font-size: 14px;
                min-width: 400px;
            }}
            .styled-table th, .styled-table td {{
                padding: 8px 12px;
                border: 1px solid #ddd;
                text-align: center;
            }}
            .styled-table th {{
                background-color: #2c3e50;
                color: white;
            }}
        </style>
    </head>
    <body>
        <h1>>> Animated Suicide Rate by State (2005–2022)</h1>
        {choropleth_html}
        <h2>>> Average Suicide Rate by State</h2>
        <div class="styled-table-wrapper">
            {table_html}
        </div>
    </body>
    </html>
    """)

print(f"\n~ Animated choropleth with table saved to: {full_html_path}")

print("\n~ Average Suicide Rate by State:")
print(tabulate(avg_rate, headers="keys", tablefmt="grid"))

# Chord Diagram (Top 5 States vs. Years)
top_states = df.groupby("state")["deaths"].sum().sort_values(ascending=False).head(5).index.tolist()
df_top = df[df["state"].isin(top_states)]

edges = df_top[["state", "year", "deaths"]].copy()
edges["year"] = edges["year"].astype(str)

print("\n Data Used for Chord Diagram (Top 5 States):")
print(tabulate(edges, headers="keys", tablefmt="grid"))

color_cycle = ['#e41a1c', '#377eb8', '#4daf4a', '#984ea3', '#ff7f00', '#999999', '#a65628']

chord = hv.Chord(edges, ['state', 'year'], 'deaths').opts(
    opts.Chord(
        cmap=color_cycle, edge_cmap=color_cycle, edge_color='state', node_color='index',
        labels='index', width=1000, height=900, edge_alpha=0.85,
        label_text_font_size="8pt",
        title="=== Chord Diagram: Top 5 States Suicide Contributions Over Years"
    )
)
chord_path = os.path.join(OUTPUT_DIR, "chord_top5_states.html")
output_file(chord_path)
save(hv.render(chord, backend='bokeh'))
print(f">> Chord diagram saved to: {chord_path}")