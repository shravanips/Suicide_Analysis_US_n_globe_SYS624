# full_world_suicide_analysis.py
# Question 10: What global and age-gender patterns emerge from international suicide trends (1985–2016)?
# Author: Shravani Sawant
# Date Last Edited: April 25, 2025 ; 8:13 PM
#
# Purpose:
#     This script analyzes global suicide patterns using the 'master.csv' dataset,
#     covering multiple demographic and economic factors. It includes:
#     - Total global suicide trends over time
#     - Gender-wise suicide differences
#     - Suicide rates by age group and generation
#     - Economic analysis linking GDP per capita to suicide rates
#     - Country-wise top suicide contributors
#     - Male vs female suicide volume comparison
#     - Age-specific suicide trends across decades
#     - Creative visualizations: line plots, sunbursts, treemaps, animated bubbles
#     All outputs are compiled into a visually structured HTML dashboard.
#
# Dataset Used: master.csv
# Path: data/world_suicide/master.csv


import pandas as pd
import plotly.express as px
import plotly.io as pio
import os
from tabulate import tabulate

# Path Setup
output_dir = '../outputs/q_world_master_analysis/'
os.makedirs(output_dir, exist_ok=True)
dashboard_html_path = output_dir + 'creative_suicide_dashboard.html'

# Load Data
file_path = '../data/world_suicide/master.csv'
df = pd.read_csv(file_path)

# Clean GDP column
df[' gdp_for_year ($) '] = df[' gdp_for_year ($) '].str.replace(',', '').astype(float)
df['HDI for year'] = df['HDI for year'].fillna(df['HDI for year'].median())


# Build Figures
figures = []

# Sub questions begins
# Q1: Global Suicide Trends

q1_df = df.groupby('year').agg({'suicides_no':'sum', 'population':'sum'}).reset_index()
q1_df['suicide_rate_per_100k'] = (q1_df['suicides_no'] / q1_df['population']) * 100000

print("\n Q1: Global Suicide Trends Over Years ")
print(tabulate(q1_df[['year', 'suicide_rate_per_100k']], headers='keys', tablefmt='pretty'))

fig1 = px.line(q1_df, x='year', y='suicide_rate_per_100k',
               title='Q1: Global Suicide Trends Over Years',
               labels={'suicide_rate_per_100k':'Suicides per 100k'},
               markers=True,
               color_discrete_sequence=['#1f77b4'])
fig1.update_layout(plot_bgcolor='rgba(240,240,240,0.9)')
figures.append(fig1)


# Q2: Gender Differences
q2_df = df.groupby(['year', 'sex']).agg({'suicides_no':'sum', 'population':'sum'}).reset_index()
q2_df['suicide_rate_per_100k'] = (q2_df['suicides_no'] / q2_df['population']) * 100000

print("\n ------------------------ ")
print("\n Q2: Gender Differences in Suicide Rates ")
print(tabulate(q2_df.head(10), headers='keys', tablefmt='pretty'))

fig2 = px.line(q2_df, x='year', y='suicide_rate_per_100k', color='sex',
               title='Q2: Gender Differences in Suicide Rates',
               markers=True,
               color_discrete_sequence=px.colors.qualitative.Set2)
figures.append(fig2)


# Q3: Suicide Rates by Age Group
q3_df = df.groupby('age').agg({'suicides_no':'sum', 'population':'sum'}).reset_index()
q3_df['suicide_rate_per_100k'] = (q3_df['suicides_no'] / q3_df['population']) * 100000

print("\n ------------------------ ")
print("\n Q3: Suicide Rates by Age Group ")
print(tabulate(q3_df, headers='keys', tablefmt='pretty'))

fig3 = px.sunburst(q3_df, path=['age'], values='suicide_rate_per_100k',
                   color='suicide_rate_per_100k', color_continuous_scale='Viridis',
                   title='Q3: Suicide Rates by Age Group (Sunburst View)')
figures.append(fig3)


# Q4: Suicide by Generation
q4_df = df.groupby('generation').agg({'suicides_no':'sum', 'population':'sum'}).reset_index()
q4_df['suicide_rate_per_100k'] = (q4_df['suicides_no'] / q4_df['population']) * 100000

print("\n ------------------------ ")
print("\n Q4: Suicide Rates by Generation ")
print(tabulate(q4_df, headers='keys', tablefmt='pretty'))

fig4 = px.treemap(q4_df, path=['generation'], values='suicide_rate_per_100k',
                  color='suicide_rate_per_100k', color_continuous_scale='Sunsetdark',
                  title='Q4: Suicide Rates by Generation (Treemap)')
figures.append(fig4)


# Q5: GDP vs Suicide Rate
q5_df = df.copy()
q5_df['suicide_rate_per_100k'] = (q5_df['suicides_no'] / q5_df['population']) * 100000

print("\n ------------------------ ")
print("\n Q5: GDP per Capita vs Suicide Rates ")
print(tabulate(q5_df[['gdp_per_capita ($)', 'suicide_rate_per_100k']].head(10), headers='keys', tablefmt='pretty'))

fig5 = px.scatter(q5_df, x='gdp_per_capita ($)', y='suicide_rate_per_100k',
                  size='population', color='year',
                  title='Q5: GDP per Capita vs Suicide Rate (Bubble View)',
                  color_continuous_scale='icefire',
                  hover_data=['country'])
figures.append(fig5)


# Q6: Top 10 Countries Suicide Rates
top_countries = df.groupby('country')['suicides_no'].sum().sort_values(ascending=False).head(10)
top_df = df[df['country'].isin(top_countries.index)]
top_grouped = top_df.groupby(['year', 'country']).agg({'suicides_no':'sum'}).reset_index()

print("\n ------------------------ ")
print("\n Q6: Top 10 Countries Suicide Rates ")
print(tabulate(top_grouped.head(10), headers='keys', tablefmt='pretty'))

fig6 = px.line(top_grouped, x='year', y='suicides_no', color='country',
               title='Q6: Top 10 Countries Suicide Trends',
               color_discrete_sequence=px.colors.qualitative.Dark2)
figures.append(fig6)


# Q7: Male vs Female Suicide Trends
mf_df = df.groupby(['year', 'sex']).agg({'suicides_no':'sum'}).reset_index()

print("\n ------------------------ ")
print("\n Q7: Male vs Female Suicide Trends ")
print(tabulate(mf_df.head(10), headers='keys', tablefmt='pretty'))

fig7 = px.area(mf_df, x='year', y='suicides_no', color='sex',
               title='Q7: Male vs Female Suicide Counts (Area View)',
               color_discrete_sequence=px.colors.sequential.Plasma)
figures.append(fig7)


# Q8: Suicide Trends by Age Across Decades
df['decade'] = (df['year'] // 10) * 10
decade_age = df.groupby(['decade', 'age']).agg({'suicides_no':'sum'}).reset_index()

print("\n ------------------------ ")
print("\n Q8: Suicide Trends by Age Group Across Decades ")
print(tabulate(decade_age.head(10), headers='keys', tablefmt='pretty'))

# Grouped Bar Chart
fig8_bar = px.bar(decade_age, x='decade', y='suicides_no', color='age',
                  title='Q8a: Suicide Trends by Age Group Across Decades (Bar View)',
                  color_discrete_sequence=px.colors.qualitative.Pastel)

# Sunburst Chart
fig8_sunburst = px.sunburst(decade_age, path=['decade', 'age'], values='suicides_no',
                            color='suicides_no', color_continuous_scale='Magma',
                            title='Q8b: Suicide Trends by Age Group Across Decades (Sunburst View)')

figures.append(fig8_bar)
figures.append(fig8_sunburst)


# Save Full Dashboard - HTML
with open(dashboard_html_path, 'w') as f:
    f.write("<html><head><title>Suicide Analysis Dashboard</title></head><body style='font-family:sans-serif;'>")
    f.write("<h1 style='text-align:center;'>Suicide Analysis Dashboard (1985–2016)</h1>")
    for i, fig in enumerate(figures, 1):
        f.write(f"<h2>Chart {i}</h2>\n")
        inner_html = pio.to_html(fig, full_html=False, include_plotlyjs='cdn')
        f.write(inner_html)
        f.write("<hr style='border:1px solid lightgray;'>")
    f.write("</body></html>")

print(f"\n >>> Creative Dashboard generated: {dashboard_html_path}")
