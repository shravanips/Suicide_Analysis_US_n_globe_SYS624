# q8_analyze_suicide_by_education.py
# Question 8: What is the relationship between suicide trends and education levels?
# Author: Shravani Sawant
# Date Last Edited: April 22, 2025 ;  10:49 PM
# Purpose:
#     This script explores how suicide incidents vary by educational background across genders and years.
#     It uses visualizations such as bar plots, line charts, heatmaps, treemaps, and bubble charts to highlight correlations.
#     Results are saved and presented via an interactive HTML dashboard for interpretability.
# Dataset Used: full_data.csv
# Path: data/full_data.csv


import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
from tabulate import tabulate

# Path Setup
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_FILE = os.path.join(BASE_DIR, "data", "full_data.csv")
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs", "q8_outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Loading and cleaning data
print("Loading full suicide dataset...")
df = pd.read_csv(DATA_FILE)
df.columns = df.columns.str.strip().str.lower()
df = df[df["intent"] == "Suicide"]
df = df.dropna(subset=["education", "sex", "year"])

# Save filtered version
filtered_path = os.path.join(OUTPUT_DIR, "q8_suicide_by_education.csv")
df.to_csv(filtered_path, index=False)
print(f"Filtered dataset saved to: {filtered_path}")

# Aggregating
grouped = df.groupby(["year", "sex", "education"]).size().reset_index(name="suicides")

# Bar plot
plt.figure(figsize=(14, 7))
sns.set_palette("Set2")  # upgraded color palette
sns.barplot(data=grouped, x="year", y="suicides", hue="education", ci=None)
plt.title("Total Suicides by Education Level Over Years")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "barplot_education_by_year.png"))
plt.close()
print("\nBarplot Data:")
print(tabulate(grouped.head(10), headers="keys", tablefmt="grid"))

# Line plot
custom_palette = sns.color_palette(["#1f77b4", "#2ca02c", "#ff7f0e", "#d62728", "#9467bd"])
plt.figure(figsize=(14, 7))
sns.lineplot(data=grouped, x="year", y="suicides", hue="education", style="sex", markers=True, palette=custom_palette)
plt.title("Suicide Trends by Education and Gender")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "lineplot_education_gender.png"))
plt.close()

# tree map (watched yt, creative plots and thought why cant we do this)
fig_treemap = px.treemap(
    grouped,
    path=["year", "education", "sex"],
    values="suicides",
    title="Suicide Distribution by Year → Education → Gender",
    color="suicides",
    color_continuous_scale="Tealrose"  # changed from Reds to Tealrose
)
fig_treemap.write_html(os.path.join(OUTPUT_DIR, "treemap_education_gender.html"))

# Bubble plot
fig_bubble = px.scatter(
    grouped,
    x="year", y="suicides", size="suicides", color="education",
    hover_data=["sex"],
    title="Bubble Chart: Suicides by Education and Gender Over Time",
    color_discrete_sequence=px.colors.qualitative.Bold  # distinct colors
)
fig_bubble.write_html(os.path.join(OUTPUT_DIR, "bubble_education_gender.html"))

# Heatmap
pivot = grouped.pivot_table(index="education", columns="year", values="suicides", aggfunc="sum")
plt.figure(figsize=(14, 6))
sns.heatmap(pivot, cmap="coolwarm", annot=True, fmt=".0f")
plt.title("Heatmap: Suicides by Education Over Years")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "heatmap_education_by_year.png"))
plt.close()
print("\nHeatmap Table:")
print(tabulate(pivot.fillna(0).astype(int).reset_index(), headers="keys", tablefmt="grid"))

# generating HTML dashboard
html_path = os.path.join(OUTPUT_DIR, "q8_dashboard.html")
with open(html_path, "w") as f:
    f.write(f"""
    <html>
    <head>
        <title>Q8 Dashboard: Suicide by Education and Gender</title>
        <style>
            body {{ font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px; }}
            .container {{ max-width: 1000px; margin: auto; background: white; padding: 20px; border-radius: 8px; }}
            h1 {{ color: #2c3e50; }}
            h2 {{ border-bottom: 1px solid #ddd; padding-bottom: 5px; }}
            img, iframe {{ width: 100%; margin-top: 15px; border-radius: 6px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Q8: Suicide Analysis by Education and Gender</h1>

            <h2>1. Bar Plot - Total Suicides by Education Over Years</h2>
            <img src="barplot_education_by_year.png">

            <h2>2. Line Plot - Suicide Trends by Education and Gender</h2>
            <img src="lineplot_education_gender.png">

            <h2>3. Treemap</h2>
            <iframe src="treemap_education_gender.html" height="500"></iframe>

            <h2>4. Bubble Chart</h2>
            <iframe src="bubble_education_gender.html" height="500"></iframe>

            <h2>5. Heatmap</h2>
            <img src="heatmap_education_by_year.png">
        </div>
    </body>
    </html>
    """)

print(f"\nAll Q8 visualizations and dashboard saved in: {OUTPUT_DIR}")
