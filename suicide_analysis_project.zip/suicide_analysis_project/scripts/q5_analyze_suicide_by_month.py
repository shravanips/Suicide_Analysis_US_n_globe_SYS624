# q5_analyze_suicide_by_month.py
# Question 5: Do suicide rates vary across different months or seasons?
# Author: Shravani Sawant
# Date last edited: April 20, 2025 ; 3:48 PM
# Purpose:
#   to analyze suicide trends by month and season, evaluate age distributions, and visualize trends across years using traditional and creative charts.
#   Outputs are saved and compiled in an interactive HTML dashboard.
# dataset used: full_data.csv
# Path: data/full_data.csv


import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import calendar
import plotly.graph_objects as go
import numpy as np
import plotly.io as pio
from tabulate import tabulate

# PATH SETUP
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_FILE = os.path.join(BASE_DIR, "data", "full_data.csv")
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs", "q5_outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# LOAD & CLEAN DATA
print("Loading full suicide dataset...")
df = pd.read_csv(DATA_FILE)
df.columns = df.columns.str.strip().str.lower()
df = df[df["intent"] == "Suicide"]

# Normalize month values
if pd.api.types.is_numeric_dtype(df["month"]):
    df["month"] = df["month"].apply(lambda x: calendar.month_name[int(x)] if not pd.isnull(x) and int(x) in range(1, 13) else "Unknown")
else:
    df["month"] = df["month"].astype(str).str.strip().str.capitalize()

# Save filtered subset
filtered_path = os.path.join(OUTPUT_DIR, "q5_suicide_by_month.csv")
df.to_csv(filtered_path, index=False)
print(f"Saved filtered dataset to: {filtered_path}")

# Traditional charts
plt.figure(figsize=(10, 6))
month_order = list(calendar.month_name)[1:]
sns.set_palette("pastel")
sns.countplot(data=df, x="month", order=month_order)
plt.title("Total Suicides Per Month", fontsize=16)
plt.xticks(rotation=45)
plt.tight_layout()
bar_path = os.path.join(OUTPUT_DIR, "barplot_suicides_per_month.png")
plt.savefig(bar_path)
plt.close()

plt.figure(figsize=(12, 6))
sns.set_palette("muted")
sns.boxplot(data=df, x="month", y="age", order=month_order)
plt.title("Age Distribution of Suicide Victims by Month", fontsize=16)
plt.xticks(rotation=45)
plt.tight_layout()
box_path = os.path.join(OUTPUT_DIR, "boxplot_age_distribution_by_month.png")
plt.savefig(box_path)
plt.close()

# Line chart (animated)
monthly_trend = df.groupby(["year", "month"]).size().reset_index(name="suicides")
monthly_trend["month"] = pd.Categorical(monthly_trend["month"], categories=month_order, ordered=True)
monthly_trend = monthly_trend.sort_values(["year", "month"])

animated_line = px.line(
    monthly_trend,
    x="month", y="suicides",
    animation_frame="year",
    title="Yearly Trend of Suicides by Month",
    labels={"suicides": "Number of Suicides"},
    markers=True,
    color_discrete_sequence=["#7b2cbf"]
)
animated_line.update_layout(transition={"duration": 600})
animated_path = os.path.join(OUTPUT_DIR, "animated_suicide_trend.html")
animated_line.write_html(animated_path)

# Creating Sunburst (season mapping)
season_map = {
    "December": "Winter", "January": "Winter", "February": "Winter",
    "March": "Spring", "April": "Spring", "May": "Spring",
    "June": "Summer", "July": "Summer", "August": "Summer",
    "September": "Autumn", "October": "Autumn", "November": "Autumn"
}
df["season"] = df["month"].map(season_map)

sunburst = px.sunburst(
    df,
    path=["season", "month"],
    title="Suicide Distribution by Season and Month",
    color_discrete_sequence=px.colors.sequential.Plasma
)
sunburst_path = os.path.join(OUTPUT_DIR, "sunburst_seasonal_suicide.html")
sunburst.write_html(sunburst_path)

# Radial chart
monthly_counts = df["month"].value_counts().reindex(month_order).dropna()
radial_counts = monthly_counts.values
angles = np.linspace(0, 2 * np.pi, len(radial_counts), endpoint=False).tolist()
angles += angles[:1]
radial_counts = np.append(radial_counts, radial_counts[0])

fig, ax = plt.subplots(figsize=(8, 8), subplot_kw={'polar': True})
ax.plot(angles, radial_counts, linewidth=2, linestyle='solid', color="#fb5607")
ax.fill(angles, radial_counts, alpha=0.25, color="#ffbe0b")
ax.set_xticks(np.linspace(0, 2 * np.pi, len(month_order), endpoint=False))
ax.set_xticklabels(month_order)
ax.set_title("Radial Calendar of Suicides by Month", y=1.08, fontsize=16)
plt.tight_layout()
radial_path = os.path.join(OUTPUT_DIR, "radial_calendar_suicide.png")
plt.savefig(radial_path)
plt.close()

# Stream graph
stream_data = monthly_trend.pivot(index="year", columns="month", values="suicides").fillna(0)
stream_data = stream_data[month_order]
stream_data.plot.area(colormap="cividis", figsize=(14, 6))
plt.title("Stream Graph: Monthly Suicide Trends Over Years", fontsize=16)
plt.xlabel("Year")
plt.ylabel("Suicides")
plt.tight_layout()
stream_path = os.path.join(OUTPUT_DIR, "streamgraph_monthly_trends.png")
plt.savefig(stream_path)
plt.close()

# Generating HTML dashboard
dashboard_path = os.path.join(OUTPUT_DIR, "q5_dashboard.html")
with open(dashboard_path, "w") as f:
    f.write('''
    <html>
    <head>
        <title>Monthly and Seasonal Suicide Analysis</title>
        <style>
            body { font-family: Arial, sans-serif; padding: 20px; text-align: center; background: #f9f9f9; }
            img { max-width: 90%; height: auto; margin: 20px auto; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
            iframe { width: 90%; height: 600px; margin: 20px auto; border: none; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
            h2 { margin-top: 40px; color: #2c3e50; }
        </style>
    </head>
    <body>
        <h1 style="color:#1a1a1a;">Suicide Trends by Month and Season</h1>

        <h2>1. Total Suicides Per Month</h2>
        <img src="barplot_suicides_per_month.png">

        <h2>2. Age Distribution by Month</h2>
        <img src="boxplot_age_distribution_by_month.png">

        <h2>3. Animated Monthly Trend Over Years</h2>
        <iframe src="animated_suicide_trend.html"></iframe>

        <h2>4. Suicide Distribution by Season and Month</h2>
        <iframe src="sunburst_seasonal_suicide.html"></iframe>

        <h2>5. Radial Calendar</h2>
        <img src="radial_calendar_suicide.png">

        <h2>6. Stream Graph of Monthly Trends Over Time</h2>
        <img src="streamgraph_monthly_trends.png">
    </body>
    </html>
    ''')

# Python console summary
print("\nSummary of Monthly Suicide Counts:")
print(tabulate(monthly_counts.reset_index().rename(columns={"index": "Month", "month": "Suicides"}), headers="keys", tablefmt="grid"))

print("\nPreview of Monthly Trend Data:")
print(tabulate(monthly_trend.head(12), headers="keys", tablefmt="grid"))

print("\nPreview of Stream Data (Monthly Suicide Trends by Year):")
print(tabulate(stream_data.head(), headers="keys", tablefmt="grid"))

print(f"\nAll Q5 visualizations and dashboard saved in: {OUTPUT_DIR}")
