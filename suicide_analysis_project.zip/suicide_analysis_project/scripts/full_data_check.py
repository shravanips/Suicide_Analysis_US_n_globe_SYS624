# full_data_check.py

"""
Script Name: full_data_check.py
Author: Shravani Sawant
Created: April 17, 2025; 2:00 PM
Description:
    Processes and summarizes suicide-related records from full_data.csv.
    Includes gender, age, race, education breakdowns and saves a visual Bokeh dashboard.
"""

import pandas as pd
import numpy as np
from math import pi
from tabulate import tabulate
from bokeh.plotting import figure, output_file, save
from bokeh.models import ColumnDataSource, Div, LabelSet
from bokeh.layouts import column
from bokeh.transform import cumsum
import os

# Load dataset
file_path = "../data/full_data.csv" # used this path as relative path was not working properly
df = pd.read_csv(file_path)

# Filter suicide intent
df = df[df['intent'] == 'Suicide'].dropna(subset=['year', 'sex', 'age', 'race', 'education'])

# Create age groups
bins = list(range(0, 110, 10)) + [150]
labels = [f"{i}-{i+9}" for i in range(0, 100, 10)] + ["100+"]
df['age_group'] = pd.cut(df['age'], bins=bins, labels=labels, right=False)

# Summary tables
summary_data = [
    ["Total Records", len(df)],
    ["Years Covered", f"{df['year'].min()} to {df['year'].max()}"],
    ["Average Age", f"{df['age'].mean():.2f}"],
    ["Age Range", f"{int(df['age'].min())} to {int(df['age'].max())}"]
]

gender_table = df['sex'].value_counts().reset_index()
gender_table.columns = ['Gender', 'Count']

race_table = df['race'].value_counts().reset_index()
race_table.columns = ['Race', 'Count']

edu_table = df['education'].value_counts().reset_index()
edu_table.columns = ['Education Level', 'Count']

age_group_table = df['age_group'].value_counts().sort_index().reset_index()
age_group_table.columns = ['Age Group', 'Count']

# Console Output
print("\n***** Suicide Dataset Summary *****")
print(tabulate(summary_data, headers=["Metric", "Value"], tablefmt="fancy_grid"))

print("\n***** Gender Distribution *****")
print(tabulate(gender_table.values.tolist(), headers=gender_table.columns, tablefmt="grid"))

print("\n***** Race Distribution *****")
print(tabulate(race_table.values.tolist(), headers=race_table.columns, tablefmt="grid"))

print("\n***** Education Distribution *****")
print(tabulate(edu_table.values.tolist(), headers=edu_table.columns, tablefmt="grid"))

print("\n***** Age Group Distribution *****")
print(tabulate(age_group_table.values.tolist(), headers=age_group_table.columns, tablefmt="grid"))

# HTML table helper
def dataframe_to_html_table(df, title):
    html = f"<h3 style='text-align:center; color:#2c3e50;'>{title}</h3>"
    html += """
    <div style='display: flex; justify-content: center;'>
    <table style='border-collapse: collapse; font-size: 16px; min-width: 400px;'>
    <tr style='background-color: #ecf0f1; text-align: center;'>"""
    for col in df.columns:
        html += f"<th style='padding: 10px; border: 1px solid #ccc;'>{col}</th>"
    html += "</tr>"
    for _, row in df.iterrows():
        html += "<tr>"
        for cell in row:
            html += f"<td style='padding: 10px; border: 1px solid #ccc; text-align: center;'>{cell}</td>"
        html += "</tr>"
    html += "</table></div><br>"
    return html

# Layout setup
layout_blocks = []
layout_blocks.append(Div(text="<h1 style='text-align:center; color:#2c3e50;'> Suicide Analysis Dashboard</h1><br>"))

# Year-wise Chart
year_counts = df['year'].value_counts().sort_index()
x_vals = [str(y) for y in year_counts.index]
year_source = ColumnDataSource(data=dict(x=x_vals, y=year_counts.values))
year_fig = figure(x_range=x_vals, title="Year-wise Distribution", height=300)
year_fig.vbar(x='x', top='y', width=0.5, color="#27ae60", source=year_source)
year_fig.add_layout(LabelSet(x='x', y='y', text='y', x_offset=-13, y_offset=5, source=year_source))
layout_blocks += [year_fig, Div(text=dataframe_to_html_table(pd.DataFrame({"Year": x_vals, "Count": year_counts.values}), "Year-wise Table"))]

# Gender Chart
gender_colors = ["#8e44ad", "#f39c12"]
gender_source = ColumnDataSource(data=dict(
    x=gender_table["Gender"].tolist(),
    y=gender_table["Count"].tolist(),
    color=gender_colors
))
gender_fig = figure(x_range=gender_table["Gender"].tolist(), title="Gender Distribution", height=300)
gender_fig.vbar(x='x', top='y', width=0.5, color='color', source=gender_source)
gender_fig.add_layout(LabelSet(x='x', y='y', text='y', x_offset=-13, y_offset=5, source=gender_source))
layout_blocks += [gender_fig, Div(text=dataframe_to_html_table(gender_table, "Gender Table"))]

# Age Histogram
hist, edges = np.histogram(df['age'], bins=20)
age_fig = figure(title="Age Distribution", height=300)
age_fig.quad(top=hist, bottom=0, left=edges[:-1], right=edges[1:], fill_color="#3498db", line_color="#2c3e50")
layout_blocks += [age_fig, Div(text=dataframe_to_html_table(age_group_table, "Age Group Table"))]

# Race Pie Chart
race_data = pd.Series(race_table["Count"].values, index=race_table["Race"]).reset_index(name='value')
race_data.columns = ["race", "value"]
race_data['angle'] = race_data['value'] / race_data['value'].sum() * 2 * pi
race_data['color'] = ["#1abc9c", "#e74c3c", "#9b59b6", "#f1c40f", "#34495e"]
race_fig = figure(height=350, title="Race Distribution", toolbar_location=None, tools="hover",
                  tooltips="@race: @value", x_range=(-0.5, 1.0))
race_fig.wedge(x=0, y=1, radius=0.4,
               start_angle=cumsum('angle', include_zero=True),
               end_angle=cumsum('angle'),
               line_color="white",
               fill_color='color',
               legend_field='race',
               source=ColumnDataSource(race_data))
race_fig.axis.visible = False
layout_blocks += [race_fig, Div(text=dataframe_to_html_table(race_table, "Race Table"))]

# Education Chart
edu_colors = ["#2980b9", "#f39c12", "#c0392b", "#2ecc71"]
edu_source = ColumnDataSource(data=dict(
    x=edu_table["Education Level"].tolist(),
    y=edu_table["Count"].tolist(),
    color=edu_colors
))
edu_fig = figure(x_range=edu_table["Education Level"].tolist(), title="Education Distribution", height=300)
edu_fig.vbar(x='x', top='y', width=0.5, color='color', source=edu_source)
edu_fig.add_layout(LabelSet(x='x', y='y', text='y', x_offset=-13, y_offset=5, source=edu_source))
layout_blocks += [edu_fig, Div(text=dataframe_to_html_table(edu_table, "Education Table"))]

# Save HTML Dashboard
os.makedirs("outputs", exist_ok=True)
output_file("outputs/suicide_dashboard_labeled_final.html", title="Suicide Dashboard Final")
save(column(*layout_blocks, sizing_mode="stretch_width"))

print(">>> Dashboard saved to: outputs/suicide_dashboard_labeled_final.html")
