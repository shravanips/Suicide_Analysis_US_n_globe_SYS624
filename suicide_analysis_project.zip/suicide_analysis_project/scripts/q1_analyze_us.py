# q1_analyze_us.py - Question 1: Does age play a role in suicide occurrence?
# Author: Shravani Sawant
# Last edited: April 17, 2025 ; 3:08 PM
# Analyzes the dataset = full_data.csv
# Purpose: Analyze whether age plays a role in suicide using grouped bar charts and tabular summaries from the full_data.csv dataset

import pandas as pd
import plotly.express as px
import os
from tabulate import tabulate

# Setting Configuration to files
DATA_PATH = "../data/full_data.csv"
OUTPUT_DIR = "../outputs"
OUTPUT_HTML = os.path.join(OUTPUT_DIR, "suicide_by_age_gender_plotly.html")

# Loading Dataset
print("\nLoading dataset...")
df = pd.read_csv(DATA_PATH)
print(f"Loaded {len(df)} rows from full_data.csv")

# Clean & Prepare Files
print("Cleaning data...")

df_filtered = df[df["intent"] == "Suicide"].copy()
df_filtered = df_filtered.dropna(subset=["age", "sex"])

# Define age groups
bins = [0, 17, 24, 34, 44, 54, 64, 74, 120]
labels = ['0-17', '18-24', '25-34', '35-44', '45-54', '55-64', '65-74', '75+']
df_filtered["age_group"] = pd.cut(df_filtered["age"], bins=bins, labels=labels, right=True)
df_filtered = df_filtered.dropna(subset=["age_group"])
df_filtered["age_group"] = pd.Categorical(df_filtered["age_group"], categories=labels, ordered=True)

# Grouping and Aggregate
age_gender_stats = df_filtered.groupby(["age_group", "sex"], observed=True).size().reset_index(name="count")

# Plotly Visualization
print("Generating interactive Plotly chart...")

fig = px.bar(
    age_gender_stats,
    x="age_group",
    y="count",
    color="sex",
    barmode="group",
    color_discrete_sequence=["#D0E4EE", "#F5A7A6"],  # Custom colors for Blue for Men and Soft Pink for Women
    labels={"count": "Number of Suicides", "age_group": "Age Group", "sex": "Gender"},
    title="Suicide Counts by Age Group and Gender (2012–2014)"
)

fig.update_layout(
    font=dict(size=14),
    title_x=0.5,
    xaxis_title="Age Group",
    yaxis_title="Number of Suicides",
    legend_title="Gender",
    bargap=0.15
)

os.makedirs(OUTPUT_DIR, exist_ok=True)
fig.write_html(OUTPUT_HTML)
fig.show()
print(f"Interactive chart saved to: {OUTPUT_HTML}")

# Console Table + Insights
print("\nSuicide Counts by Age Group and Gender:")
print(tabulate(age_gender_stats, headers="keys", tablefmt="grid"))

if not df_filtered.empty:
    top_age = age_gender_stats.groupby("age_group")["count"].sum().idxmax()
    top_gender = df_filtered["sex"].value_counts().idxmax()

    print("\nSummary Insights:")
    print(f"- Most affected age group: {top_age}")
    print(f"- Most affected gender   : {top_gender}")
    print("- Gender gap is visible across most age groups.")
    print("- Middle-aged individuals show higher suicide counts. Suggest exploring contributing factors.")
else:
    print("No data available after filtering.")
