# q9_analyze_suicide_by_race.py
# Question 9: How do suicide trends vary across different racial groups and genders?
# Author: Shravani Sawant
# Date Last Edited: April 23, 2025 ; 8:45 am
# Purpose:
#     This script investigates the relationship between race and suicide rates,
#     along with gender- and age-based differences. It includes:
#     - Traditional bar plot
#     - A multi-level Sankey diagram: Race → Gender → Age Group
#     All outputs are compiled in a visual HTML dashboard.
# Dataset Used: full_data.csv
# Path: data/full_data.csv


import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
from tabulate import tabulate
import random

# Path setup
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_FILE = os.path.join(BASE_DIR, "data", "full_data.csv")
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs", "q9_outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Loading and cleaning the data
print("Loading full suicide dataset...")
df = pd.read_csv(DATA_FILE)
df.columns = df.columns.str.strip().str.lower()
df = df[df["intent"] == "Suicide"]
df = df.dropna(subset=["race", "sex", "age"])

# Add age group buckets
bins = [0, 18, 30, 45, 60, 100]
labels = ["0–18", "19–30", "31–45", "46–60", "60+"]
df["age_group"] = pd.cut(df["age"], bins=bins, labels=labels, right=False)

# Save filtered data
filtered_path = os.path.join(OUTPUT_DIR, "q9_suicide_by_race.csv")
df.to_csv(filtered_path, index=False)
print(f"Cleaned dataset saved to: {filtered_path}")

# Count plot
plt.figure(figsize=(10, 6))
sns.countplot(data=df, x="race", palette="Set2")
plt.title("Total Suicides by Race")
plt.xticks(rotation=45)
plt.tight_layout()
barplot_path = os.path.join(OUTPUT_DIR, "barplot_suicides_by_race.png")
plt.savefig(barplot_path)
plt.close()

# Console Output - python
race_counts = df["race"].value_counts().reset_index()
race_counts.columns = ["Race", "Suicide Count"]
print("\nBarplot Data: Suicides by Race")
print(tabulate(race_counts, headers="keys", tablefmt="grid"))

# Sankey: Race → Gender → Age
sankey_data = df.groupby(["race", "sex", "age_group"]).size().reset_index(name="count")

# Build labels and mapping
labels = list(pd.unique(sankey_data[["race", "sex", "age_group"]].values.ravel()))
label_indices = {label: i for i, label in enumerate(labels)}

# Source → Intermediate → Target (Race → Sex → Age)
source = sankey_data["race"].map(label_indices).tolist()
intermediate = sankey_data["sex"].map(label_indices).tolist()
target = sankey_data["age_group"].map(label_indices).tolist()

sources = source + intermediate
targets = intermediate + target
values = sankey_data["count"].tolist() * 2

# Define updated vibrant pastel node colors
pastel_palette = [
    "#FADADD", "#D5AAFF", "#FFCBC1", "#C1E1C1", "#FFDAB9",
    "#B0E0E6", "#E6E6FA", "#F0E68C", "#FFB6C1", "#D8BFD8",
    "#98FB98", "#E0FFFF", "#FFFACD", "#FFE4E1", "#C6E2FF"
]
node_colors = (pastel_palette * ((len(labels) // len(pastel_palette)) + 1))[:len(labels)]

# Generate smoother flow link colors
random.seed(99)
link_colors = [
    f"rgba({random.randint(130, 200)}, {random.randint(150, 210)}, {random.randint(170, 230)}, 0.7)"
    for _ in range(len(sources))
]

sankey_fig = go.Figure(data=[go.Sankey(
    node=dict(
        pad=15,
        thickness=20,
        line=dict(color="black", width=0.5),
        label=labels,
        color=node_colors
    ),
    link=dict(
        source=sources,
        target=targets,
        value=values,
        color=link_colors
    )
)])
sankey_fig.update_layout(
    title_text="Sankey Diagram: Race → Gender → Age Group",
    font_size=11,
    height=600,
    width=1000
)
sankey_path = os.path.join(OUTPUT_DIR, "sankey_race_gender_agegroup.html")
sankey_fig.write_html(sankey_path)

print("\nSankey diagram saved to:", sankey_path)
print("\nSankey Flow Data: Race → Gender → Age Group")
print(tabulate(sankey_data.head(10), headers="keys", tablefmt="grid"))

# Generating HTML dashboard
dash_path = os.path.join(OUTPUT_DIR, "q9_dashboard.html")
with open(dash_path, "w") as f:
    f.write(f"""
    <html>
    <head>
        <title>Q9 Dashboard: Suicide by Race, Gender, and Age</title>
        <style>
            body {{ font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }}
            .container {{ max-width: 1000px; margin: auto; background: white; padding: 20px; border-radius: 8px; }}
            h1 {{ color: #2c3e50; }}
            h2 {{ border-bottom: 1px solid #ddd; padding-bottom: 5px; }}
            img, iframe {{ width: 100%; margin-top: 15px; border-radius: 6px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Q9: Suicide Analysis by Race, Gender, and Age</h1>

            <h2>1. Bar Plot - Total Suicides by Race</h2>
            <img src="barplot_suicides_by_race.png">

            <h2>2. Sankey Diagram - Race → Gender → Age Group</h2>
            <iframe src="sankey_race_gender_agegroup.html" height="600"></iframe>
        </div>
    </body>
    </html>
    """)

print("\nDashboard saved to:", dash_path)
print("\nAll Q9 outputs saved successfully.")
