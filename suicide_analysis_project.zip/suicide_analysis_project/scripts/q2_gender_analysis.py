# q2_gender_analysis.py - Question 2: Is one gender more prone to suicide?
# Author: Shravani Sawant
# Last edited: April 17, 2025; 8:23 PM
# Analyzes the dataset = full_data.csv
# Interactive Plotly Dashboard for Gender-Based Suicide Distribution

import pandas as pd
import plotly.express as px
import os
from tabulate import tabulate

# Configuration to proper path
DATA_FILE = "../data/full_data.csv"
OUTPUT_DIR = "../outputs"
OUTPUT_HTML = os.path.join(OUTPUT_DIR, "suicide_by_gender_plotly.html")

# Loading Dataset
print("\nLoading dataset...")
df = pd.read_csv(DATA_FILE)
print(f"Loaded {len(df)} rows from full_data.csv")

# Filter Suicide Cases
df = df[df["intent"].str.lower() == "suicide"]
df = df.dropna(subset=["sex"])

# Grouping by Gender
gender_counts = df["sex"].value_counts().reset_index()
gender_counts.columns = ["Gender", "Suicide Count"]

# Calculate Percentages
total = gender_counts["Suicide Count"].sum()
gender_counts["Percentage"] = (gender_counts["Suicide Count"] / total * 100).round(2)

# Visualization with Plotly
print("Generating interactive Plotly chart...")

fig = px.bar(
    gender_counts,
    x="Gender",
    y="Suicide Count",
    color="Gender",
    color_discrete_sequence=["#D0E4EE", "#F5A7A6"],
    text="Suicide Count",
    title="Suicide Counts by Gender (2012–2014)"
)

fig.update_traces(texttemplate='%{text}', textposition='outside')
fig.update_layout(
    uniformtext_minsize=12,
    uniformtext_mode='hide',
    font=dict(size=14),
    title_x=0.5,
    yaxis_title="Number of Suicides",
    xaxis_title="Gender",
    legend_title_text="Gender",
    bargap=0.4
)

# Save HTML
os.makedirs(OUTPUT_DIR, exist_ok=True)
fig.write_html(OUTPUT_HTML)
print(f">>> Chart saved to: {OUTPUT_HTML}")
fig.show()

# Console Summary
print("\nSuicide Counts by Gender:")
print(tabulate(gender_counts[["Gender", "Suicide Count"]], headers="keys", tablefmt="grid"))

print("\nPercentage Distribution:")
print(tabulate(gender_counts[["Gender", "Percentage"]], headers="keys", tablefmt="grid"))

most_affected = gender_counts.loc[gender_counts["Suicide Count"].idxmax(), "Gender"]
print(f"\nSummary Insight:")
print(f"- Most affected gender: {most_affected}")
print("- Male suicide count is significantly higher. Suggest deeper analysis on contributing cultural, psychological, and socioeconomic factors.")
