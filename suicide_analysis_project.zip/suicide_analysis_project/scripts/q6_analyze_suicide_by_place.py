# q6_analyze_suicide_by_place.py
# Question 6: How does the location (place) of suicides vary over time and across age groups?
# Author: Shravani Sawant
# Date last edited: April 20, 2025 ; 8:51 PM
# Purpose:
#   To analyze trends in suicide incidents based on location (place), examining year-wise variation,
#     age distributions, and proportional changes. Visualizations include bar charts, line plots,
#     sunburst diagrams, area charts, and violin plots. All outputs are compiled in a detailed HTML dashboard.
# Dataset Used: full_data.csv
# Path: data/full_data.csv


import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
from tabulate import tabulate

# Path setup
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_FILE = os.path.join(BASE_DIR, "data", "full_data.csv")
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs", "q6_outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Loading the data
print("Loading full suicide dataset...")
df = pd.read_csv(DATA_FILE)
df.columns = df.columns.str.strip().str.lower()
df = df[df["intent"] == "Suicide"]
df = df.dropna(subset=["place"])

# Save filtered version
filtered_path = os.path.join(OUTPUT_DIR, "q6_suicide_by_place.csv")
df.to_csv(filtered_path, index=False)
print(f"Filtered dataset saved to: {filtered_path}")

# Bar plots (traditional)
plt.figure(figsize=(12, 6))
sns.countplot(data=df, y="place", order=df["place"].value_counts().index, palette="flare")
plt.title("Total Suicides by Location (Place)")
plt.xlabel("Number of Suicides")
plt.tight_layout()
bar_path = os.path.join(OUTPUT_DIR, "barplot_suicides_by_place.png")
plt.savefig(bar_path)
plt.close()

print("\nTop Locations by Suicide Count:")
place_counts = df["place"].value_counts().reset_index()
place_counts.columns = ["Place", "Suicides"]
print(tabulate(place_counts.head(10), headers="keys", tablefmt="grid"))

# Line Chart by Year (traditional)
year_place = df.groupby(["year", "place"]).size().reset_index(name="count")
plt.figure(figsize=(14, 7))
sns.lineplot(data=year_place, x="year", y="count", hue="place", marker="o")
plt.title("Yearly Suicide Trends by Location")
plt.ylabel("Suicides")
plt.tight_layout()
line_path = os.path.join(OUTPUT_DIR, "lineplot_place_trends_by_year.png")
plt.savefig(line_path)
plt.close()

print("\nSample Data: Yearly Suicide Trends by Place")
print(tabulate(year_place.head(10), headers="keys", tablefmt="grid"))

# Sunburst Chart (creative)
fig_sunburst = px.sunburst(
    df,
    path=["place", "year"],
    title="Suicide Breakdown by Location and Year",
    color_discrete_sequence=px.colors.sequential.Reds
)
sunburst_path = os.path.join(OUTPUT_DIR, "sunburst_place_year.html")
fig_sunburst.write_html(sunburst_path)

# Stack chart (creative)
pivot_data = year_place.pivot(index="year", columns="place", values="count").fillna(0)
pivot_data_percent = pivot_data.div(pivot_data.sum(axis=1), axis=0)

pivot_data_percent.plot.area(figsize=(14, 7), colormap="tab20", alpha=0.85)
plt.title("Proportional Suicide Distribution by Location (2005–2022)")
plt.ylabel("Proportion")
plt.xlabel("Year")
plt.tight_layout()
area_path = os.path.join(OUTPUT_DIR, "stacked_area_suicide_by_place.png")
plt.savefig(area_path)
plt.close()

print("\nPreview of Stacked Area Plot Data:")
print(tabulate(pivot_data_percent.head(), headers="keys", tablefmt="grid"))

# Violin plot (creative) (also influenced because I studied this in CS 810 E Automated security)
plt.figure(figsize=(14, 7))
sns.violinplot(data=df, x="place", y="age", palette="Set2", inner="quartile")
plt.xticks(rotation=45)
plt.title("Age Distribution of Suicides by Location")
plt.tight_layout()
violin_path = os.path.join(OUTPUT_DIR, "violinplot_age_by_place.png")
plt.savefig(violin_path)
plt.close()

# Generating HTML
dashboard_path = os.path.join(OUTPUT_DIR, "q6_dashboard.html")
with open(dashboard_path, "w") as f:
    f.write('''
    <html>
    <head>
        <title>Q6 Dashboard: Suicide by Place</title>
        <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4; padding: 30px; color: #333; }
            .container { max-width: 1100px; margin: auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
            h1 { color: #b30000; margin-bottom: 30px; }
            h2 { margin-top: 40px; color: #444; border-bottom: 2px solid #ddd; padding-bottom: 8px; }
            img, iframe { width: 100%; margin-top: 15px; border-radius: 8px; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Suicide Trends by Location (Q6 Analysis)</h1>

            <h2>1. Total Suicides by Location</h2>
            <img src="barplot_suicides_by_place.png">

            <h2>2. Yearly Trends by Location</h2>
            <img src="lineplot_place_trends_by_year.png">

            <h2>3. Location-Year Breakdown (Sunburst View)</h2>
            <iframe height="600" src="sunburst_place_year.html"></iframe>

            <h2>4. Proportional Trends by Location</h2>
            <img src="stacked_area_suicide_by_place.png">

            <h2>5. Age Distribution by Location</h2>
            <img src="violinplot_age_by_place.png">
        </div>
    </body>
    </html>
    ''')

print(f"\nAll Q6 visualizations and dashboard saved in: {OUTPUT_DIR}")
