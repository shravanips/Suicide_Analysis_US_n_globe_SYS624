# q7_analyze_place_vs_demographics.py
# Question 7: How does the location of suicides vary by demographic factors like age and sex?
# Author: Shravani Sawant
# Date Last Edited: April 22 2025 ; 1:45 PM
# Purpose:
#     This script analyzes how suicide locations (places) vary across demographic categories like sex and age groups.
#     It produces both traditional and advanced visualizations (bar plots, radial chart, chord, Sankey, bump chart).
#     These outputs help identify trends in demographic-location relationships over time.
#
# Dataset Used: full_data.csv
# Path: data/full_data.csv


import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from tabulate import tabulate
import holoviews as hv
from holoviews import opts
from bokeh.io import save

hv.extension('bokeh')

# Path Setup
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_FILE = os.path.join(BASE_DIR, "data", "full_data.csv")
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs", "q7_outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Loading and cleaning data
print("Loading full suicide dataset...")
df = pd.read_csv(DATA_FILE)
df.columns = df.columns.str.strip().str.lower()
df = df[df["intent"] == "Suicide"]
df = df.dropna(subset=["place", "sex", "age"])

# Group age into bins
age_bins = [0, 18, 30, 45, 60, 100]
age_labels = ["0–18", "19–30", "31–45", "46–60", "60+"]
df["age_group"] = pd.cut(df["age"], bins=age_bins, labels=age_labels, right=False)

# Save cleaned subset
filtered_path = os.path.join(OUTPUT_DIR, "q7_place_demographics.csv")
df.to_csv(filtered_path, index=False)
print(f"Cleaned dataset saved to: {filtered_path}")

# Grouped Bar plot
top_places = df["place"].value_counts().nlargest(6).index.tolist()
df_top = df[df["place"].isin(top_places)]

plt.figure(figsize=(12, 6))
sns.set_palette("Set3")
sns.countplot(data=df_top, x="place", hue="sex", order=top_places)
plt.title("Suicide Location by Gender (Top 6 Places)")
plt.xticks(rotation=45)
plt.tight_layout()
barplot_path = os.path.join(OUTPUT_DIR, "barplot_place_by_sex.png")
plt.savefig(barplot_path)
plt.close()

print("\nGrouped Barplot Data: Top 6 Places by Gender")
gender_place_data = df_top.groupby(["place", "sex"]).size().reset_index(name="count")
print(tabulate(gender_place_data.head(10), headers="keys", tablefmt="grid"))

# Radial chart
radial_data = df_top.groupby(["place", "sex"]).size().reset_index(name="count")
fig_radial = px.line_polar(
    radial_data, r="count", theta="place", color="sex", line_close=True,
    title="Radial Chart - Gender Spread Across Suicide Locations",
    color_discrete_sequence=px.colors.qualitative.Dark2
)
fig_radial.update_layout(margin=dict(t=50, l=30, r=30, b=30), height=600)
radial_path = os.path.join(OUTPUT_DIR, "radial_chart_place_gender_colored.html")
fig_radial.write_html(radial_path)

print("\nRadial Chart Summary:")
print(tabulate(radial_data.head(10), headers="keys", tablefmt="grid"))

# Chord diagram
chord_data = df_top.groupby(["sex", "place"]).size().reset_index(name="count")
links = chord_data.rename(columns={"sex": "source", "place": "target", "count": "value"})
chord = hv.Chord(links)
chord.opts(
    opts.Chord(
        labels="index", cmap="Category20b", edge_color="source",
        edge_cmap="Category20c", edge_color_index="source",
        width=800, height=600, title="Chord Diagram – Gender to Place Flows"
    )
)
chord_path = os.path.join(OUTPUT_DIR, "chord_gender_place.html")
save(hv.render(chord, backend='bokeh'), chord_path)

print("\nChord Diagram Data:")
print(tabulate(chord_data.head(10), headers="keys", tablefmt="grid"))

# Sankey diagram (I tried this because when professor was showing the new graphs of the reference paper's this influenced me to do datastorytelling from the different perspectives)
sankey_data = df_top.groupby(["sex", "place", "age_group"]).size().reset_index(name="count")
labels = list(pd.unique(sankey_data[["sex", "place", "age_group"]].values.ravel()))
label_idx = {label: i for i, label in enumerate(labels)}
source = sankey_data["sex"].map(label_idx)
target = sankey_data["place"].map(label_idx)
intermediate = sankey_data["place"].map(label_idx)
target2 = sankey_data["age_group"].map(label_idx)

node_colors = px.colors.qualitative.Dark2 * 3
link_colors = px.colors.qualitative.Pastel1 * (len(source) + len(target2))

sankey = go.Figure(data=[go.Sankey(
    node=dict(
        pad=15, thickness=20, line=dict(color="black", width=0.5),
        label=labels, color=node_colors[:len(labels)]
    ),
    link=dict(
        source=list(source) + list(intermediate),
        target=list(intermediate) + list(target2),
        value=list(sankey_data["count"]) + list(sankey_data["count"]),
        color=link_colors[:len(source) + len(target2)]
    )
)])
sankey.update_layout(title_text="Sankey Diagram – Sex to Place to Age Group", font_size=11)
sankey_path = os.path.join(OUTPUT_DIR, "sankey_sex_place_age.html")
sankey.write_html(sankey_path)

print("\nSankey Flow Data (Sex -> Place -> Age Group):")
print(tabulate(sankey_data.head(10), headers="keys", tablefmt="grid"))

# Bump charts
pivot_rank = (
    df_top.groupby(["year", "place", "sex"])
    .size().reset_index(name="count")
    .sort_values(["year", "sex", "count"], ascending=[True, True, False])
)
pivot_rank["rank"] = pivot_rank.groupby(["year", "sex"])["count"].rank("dense", ascending=False)
top_places_final = pivot_rank.groupby("place")["count"].sum().nlargest(5).index.tolist()
pivot_rank = pivot_rank[pivot_rank["place"].isin(top_places_final)]

fig_bump = px.line(
    pivot_rank, x="year", y="rank", color="place", line_group="sex", markers=True,
    title="Bump Chart - Gender Rank of Suicide Locations Over Time",
    labels={"rank": "Rank (Lower is Higher)"},
    color_discrete_sequence=px.colors.qualitative.Dark2
)
fig_bump.update_yaxes(autorange="reversed")
bump_path = os.path.join(OUTPUT_DIR, "bump_chart_location_gender_rank.html")
fig_bump.write_html(bump_path)

print("\nBump Chart Rank Data:")
print(tabulate(pivot_rank.head(10), headers="keys", tablefmt="grid"))

# Generating HTML dashboard
dash_path = os.path.join(OUTPUT_DIR, "q7_dashboard.html")
with open(dash_path, "w") as f:
    f.write('''
    <html>
    <head>
        <title>Q7 Dashboard: Suicide by Place, Gender, and Age</title>
        <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f9f9f9; padding: 30px; color: #222; }
            .container { max-width: 1100px; margin: auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
            h1 { color: #004466; margin-bottom: 30px; }
            h2 { margin-top: 40px; color: #444; border-bottom: 2px solid #ddd; padding-bottom: 8px; }
            img, iframe { width: 100%; margin-top: 15px; border-radius: 8px; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Q7: Suicide by Place, Gender, and Age Group</h1>

            <h2>1. Barplot - Suicide Location by Gender</h2>
            <img src="barplot_place_by_sex.png">

            <h2>2. Radial Chart</h2>
            <iframe src="radial_chart_place_gender_colored.html" height="600" style="border:none;"></iframe>

            <h2>3. Chord Diagram</h2>
            <iframe src="chord_gender_place.html" height="600" style="border:none;"></iframe>

            <h2>4. Sankey Flow: Sex → Place → Age Group</h2>
            <iframe src="sankey_sex_place_age.html" height="600" style="border:none;"></iframe>

            <h2>5. Bump Chart: Place Rank by Gender Over Time</h2>
            <iframe src="bump_chart_location_gender_rank.html" height="600" style="border:none;"></iframe>
        </div>
    </body>
    </html>
    ''')

print("\nAll Q7 visualizations and dashboard saved in:", OUTPUT_DIR)